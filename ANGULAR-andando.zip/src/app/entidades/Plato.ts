
export class Plato {
    id: number;
    nombre: string;
    precio: number;
    rubro: string;
    imagenPath: string;
    ingredientes: [];
}